#define cmb "/storage/emulated/0/Download/file"
#include <sys/stat.h>

float fug=1037.0f;
extern int pan;
int pn;

char *czeo(char* size)
{
	chmod(cmb, S_IRWXU);
	this=create();
	
	float width=atof(before(size,":"));
	float height=atof(after(size,":"));
	float perone=width/100.0;
	
	//percent animation
	pn++;
	if(pn>99)pn=0;
	
	//progression : bar width [px]
	fug=perone*pn;
	
	//transmit back 
	char *result=( char* ) malloc(1024);
	sprintf(result, "%d:%d",(int)(pn/6), (int) fug);
    return result;
	
}
