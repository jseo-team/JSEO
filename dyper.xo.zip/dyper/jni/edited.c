#define cmb "czeo SYNC ..... ok."

float fug=1037.0f;

char *czeo(char* size)
{
	float width=atof(before(size,":"));
	float height=atof(after(size,":"));
	float perone=width/100.0;
	//progression : bar width [px]
	fug+=perone;
	if(fug>=0.87*width)fug=0.6*width;
	
	//transmit back 
	char *result=( char* ) malloc(1024);
	sprintf(result, "%d",(int) fug);
    return result;
	
}
